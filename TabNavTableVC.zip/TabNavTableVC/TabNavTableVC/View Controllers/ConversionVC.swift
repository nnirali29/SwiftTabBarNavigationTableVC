//
//  ConversionVC.swift
//  TabNavTableVC
//
//  Created by Patel, Nirali Arvindbhai on 10/3/19.
//  Copyright © 2019 Patel, Nirali Arvindbhai. All rights reserved.
//

import UIKit

class ConversionVC: UIViewController, UITextFieldDelegate {

    var Passedlabel = ""
   
    
    
    @IBOutlet weak var lblConversion: UILabel!
    @IBOutlet weak var tf1: UITextField!
    @IBOutlet weak var lblOutput: UILabel!
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
      //  tf1.becomeFirstResponder()
        lblConversion.text = Passedlabel
        
    }
 /*   override func viewWillAppear(_ animated: Bool) {
        tf1.becomeFirstResponder()
        tf1.text = nil
    }
    */
    
   
    @IBAction func btnConvert(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        
        var inp = ""
           inp = tf1.text!
           var input = Double(inp)
           
        switch Passedlabel{
           case "Kilometers to Miles" :
                print("k2m")
                lblOutput.text = String(input! * (0.621371))
           case "Miles to Kilometers" :
                print("m2k")
                lblOutput.text = String(input! * (1.60934))
           case "Yard to Feet" :
                lblOutput.text = String(input! * (3))
           case "Feet to Yard" :
                lblOutput.text = String(input! * (0.33333))
           case "Inches to Centimeters" :
                lblOutput.text = String(input! * (2.54))
           case "Centimeters to Inches" :
                lblOutput.text = String(input! * (0.3937))
           case "Liters to Gallons" :
                lblOutput.text = String(input! * (0.264172))
           case "Gallons to Liters" :
                lblOutput.text = String(input! * (3.78541))
           case "Pints to Gallons" :
                lblOutput.text = String(input! * (0.125))
           case "Gallons to Pints" :
                lblOutput.text = String(input! * (9.60762))
           case "Quarts to Gallons" :
                lblOutput.text = String(input! * (0.20817))
           case "Gallons to Quarts" :
                lblOutput.text = String(input! * (4.80381))
           case "Fahrenheit to Celsius" :
                lblOutput.text = String((input! - 32) * (0.5555))
           case "Celsius to Fahrenheit" :
                lblOutput.text = String((input! * (1.8)) + 32)
           case "Kilograms to Pounds" :
                lblOutput.text = String(input! * (2.20462))
           case "Pounds to Kilograms" :
                lblOutput.text = String(input! * (0.453592))
           case "Ounce to Grams" :
                lblOutput.text = String(input! * (28.3495))
           case "Grams to Ounce" :
                lblOutput.text = String(input! * (0.035274))
           default:
               print("error")
           }
           
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        tf1.resignFirstResponder()
        return true
    }
    
}
