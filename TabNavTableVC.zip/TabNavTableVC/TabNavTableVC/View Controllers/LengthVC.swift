//
//  LengthVC.swift
//  TabNavTableVC
//
//  Created by Patel, Nirali Arvindbhai on 10/3/19.
//  Copyright © 2019 Patel, Nirali Arvindbhai. All rights reserved.
//

import UIKit

class LengthVC: UITableViewController {
    
   var selectedrow = ""
 let length_array = ["Kilometers to Miles" , "Miles to Kilometers" , "Yard to Feet" , "Feet to Yard" , "Inches to Centimeters" , "Centimeters to Inches"]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return length_array.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath)

        // Configure the cell...
        cell.textLabel?.text = length_array[indexPath.row]

        return cell
    }
    
  
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedrow = self.length_array[indexPath.row]
       print(selectedrow)
       
      
       performSegue(withIdentifier: "Length2Conversion", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if segue.identifier == "Length2Conversion"{
            if let conVC = segue.destination as? ConversionVC{
            print(selectedrow)
                conVC.Passedlabel = selectedrow
            }
           }
           
       }
    
}

   
